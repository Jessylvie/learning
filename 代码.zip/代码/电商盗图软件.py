import cv2
import numpy as np
from PIL import Image, ImageTk, ImageGrab
import tkinter as tk
from tkinter import ttk, messagebox
import imagehash
import threading


class AntiTheftApp:
    def __init__(self, root):
        self.root = root
        self.root.title("电商盗图检测工具 v4 - 融合增强版")
        self.root.geometry("1350x720")
        self.root.configure(bg="#1e1e2e")

        self.img1_pil = None
        self.img2_pil = None
        self.img1_list = []   # 多张原图列表
        self.paste_mode = "original"  # "original" 粘贴原图 / "test" 粘贴待测图
        self.orb = cv2.ORB_create(8000)

        self.setup_ui()

    # ═══════════════════════════ UI ═══════════════════════════

    def setup_ui(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("green.Horizontal.TProgressbar",
                        troughcolor="#313244", background="#a6e3a1")

        top = tk.Frame(self.root, bg="#1e1e2e")
        top.pack(fill=tk.BOTH, expand=True, padx=12, pady=10)

        self.canvas1 = self._make_panel(top, "① 原图  (Ctrl+V 粘贴)", 0)
        self.canvas2 = self._make_panel(top, "② 待测图 (Ctrl+V 粘贴)", 1)
        self.canvas3 = self._make_panel(top, "③ 检测结果 (红框=命中区域)", 2)

        # 日志区
        log_frame = tk.LabelFrame(top, text="检测日志", bg="#1e1e2e", fg="#cdd6f4",
                                  font=("Consolas", 9))
        log_frame.grid(row=0, column=3, sticky="nsew", padx=6)
        top.columnconfigure(3, weight=1)
        self.log_box = tk.Text(log_frame, width=34, bg="#181825", fg="#cdd6f4",
                               font=("Consolas", 9), relief=tk.FLAT)
        self.log_box.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        # 分数条
        score_frame = tk.Frame(self.root, bg="#1e1e2e")
        score_frame.pack(fill=tk.X, padx=12)
        tk.Label(score_frame, text="综合相似度", bg="#1e1e2e", fg="#cdd6f4",
                 font=("Consolas", 9)).pack(side=tk.LEFT)
        self.score_bar = ttk.Progressbar(score_frame, length=420, maximum=100,
                                         style="green.Horizontal.TProgressbar")
        self.score_bar.pack(side=tk.LEFT, padx=8)
        self.score_label = tk.Label(score_frame, text="—", bg="#1e1e2e",
                                    fg="#cdd6f4", font=("Consolas", 11, "bold"))
        self.score_label.pack(side=tk.LEFT)

        # ── URL 输入区 ──────────────────────────────────────
        url_frame = tk.Frame(self.root, bg="#1e1e2e")
        url_frame.pack(fill=tk.X, padx=12, pady=(0, 2))

        tk.Label(url_frame, text="原图 URL（每行一条）",
                 bg="#1e1e2e", fg="#cdd6f4", font=("Consolas", 9)).pack(side=tk.LEFT)

        def load_and_refocus():
            self.root.focus_set()
            self.load_btn.config(state=tk.DISABLED, text="下载中…")
            t = threading.Thread(target=self._load_url_thread, daemon=True)
            t.start()
        self.load_btn = tk.Button(url_frame, text="批量载入①", command=load_and_refocus,
                  bg="#89b4fa", fg="#1e1e2e", font=("Microsoft YaHei", 9, "bold"),
                  relief=tk.FLAT, padx=8)
        self.load_btn.pack(side=tk.RIGHT)

        self.url1_text = tk.Text(self.root, height=3, bg="#313244", fg="#cdd6f4",
                                 insertbackground="#cdd6f4", font=("Consolas", 9),
                                 relief=tk.FLAT, wrap=tk.NONE)
        self.url1_text.pack(fill=tk.X, padx=12, pady=(0, 4))
        self.url1_text.bind("<FocusOut>", lambda e: self.root.focus_set())

        # ── 粘贴模式提示栏 ──────────────────────────────────
        hint_frame = tk.Frame(self.root, bg="#313244")
        hint_frame.pack(fill=tk.X, padx=12, pady=(0, 4))
        self.hint_label = tk.Label(
            hint_frame,
            text="📋  也可直接 Ctrl+V 粘贴原图（多次），粘完点「原图粘贴完毕」再粘待测图",
            bg="#313244", fg="#f9e2af", font=("Microsoft YaHei", 9), anchor="w")
        self.hint_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=8, pady=4)
        tk.Button(hint_frame, text="✔ 原图粘贴完毕",
                  command=self.confirm_originals,
                  bg="#f9e2af", fg="#1e1e2e", font=("Microsoft YaHei", 9, "bold"),
                  relief=tk.FLAT, padx=10).pack(side=tk.RIGHT, padx=6, pady=2)

        # 按钮行
        btn_frame = tk.Frame(self.root, bg="#1e1e2e")
        btn_frame.pack(fill=tk.X, padx=12, pady=6)
        self.detect_btn = tk.Button(
            btn_frame, text="▶  开始深度检测", command=self.start_detection,
            bg="#a6e3a1", fg="#1e1e2e", font=("Microsoft YaHei", 10, "bold"),
            height=2, width=22, relief=tk.FLAT)
        self.detect_btn.pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="↺  清空重置", command=self.reset_all,
                  bg="#f38ba8", fg="#1e1e2e", font=("Microsoft YaHei", 10, "bold"),
                  height=2, width=16, relief=tk.FLAT).pack(side=tk.LEFT, padx=5)

        # Ctrl+V：剪贴板是图片就粘贴截图，是文字就让控件自己处理
        def smart_paste(event):
            from PIL import ImageGrab
            clip = ImageGrab.grabclipboard()
            if isinstance(clip, Image.Image):
                # 剪贴板是图片，无论焦点在哪都触发图片粘贴
                self.handle_paste(event)
                return "break"  # 阻止控件默认粘贴行为
            # 剪贴板是文字，放行让文本框自己处理
        self.root.bind("<Control-v>", smart_paste)

    def _make_panel(self, parent, title, col):
        frame = tk.LabelFrame(parent, text=title, bg="#1e1e2e", fg="#cdd6f4",
                              font=("Microsoft YaHei", 9))
        frame.grid(row=0, column=col, padx=5, sticky="nsew")
        parent.columnconfigure(col, weight=1)
        canvas = tk.Canvas(frame, width=310, height=480, bg="#313244",
                           highlightthickness=0)
        canvas.pack(padx=6, pady=6)
        return canvas

    def log(self, text, tag="normal"):
        colors = {"red": "#f38ba8", "green": "#a6e3a1",
                  "yellow": "#f9e2af", "cyan": "#89dceb", "normal": "#cdd6f4"}
        self.log_box.insert(tk.END, text + "\n", tag)
        self.log_box.tag_config(tag, foreground=colors.get(tag, "#cdd6f4"))
        self.log_box.see(tk.END)

    def load_from_url(self, slot: int):
        """兼容旧调用，直接启动线程版本"""
        self.load_btn.config(state=tk.DISABLED, text="下载中…")
        t = threading.Thread(target=self._load_url_thread, daemon=True)
        t.start()

    def _load_url_thread(self):
        """在子线程中下载 URL 图片，避免 UI 卡死"""
        try:
            import requests
        except ImportError:
            self.root.after(0, lambda: messagebox.showerror("缺少依赖", "请先安装 requests 库：\npip install requests"))
            self.root.after(0, lambda: self.load_btn.config(state=tk.NORMAL, text="批量载入①"))
            return
        try:
            self._do_load_urls()
        except Exception as e:
            err = str(e)
            self.root.after(0, lambda: self.log(f"✘ 载入时发生错误: {err}", "red"))
            self.root.after(0, lambda: self.load_btn.config(state=tk.NORMAL, text="批量载入①"))

    def _do_load_urls(self):
        from io import BytesIO

        raw = self.url1_text.get("1.0", tk.END)
        urls = [u.strip() for u in raw.splitlines()
                if u.strip() and not u.strip().startswith("#")]

        if not urls:
            self.root.after(0, lambda: messagebox.showwarning("提示", "请先输入至少一条 URL"))
            self.root.after(0, lambda: self.load_btn.config(state=tk.NORMAL, text="批量载入①"))
            return

        self.root.after(0, lambda: self.log(f"⏳ 开始下载原图，共 {len(urls)} 条…", "yellow"))

        # 尝试启动 selenium Chrome
        use_selenium = False
        driver = None
        try:
            from selenium import webdriver
            from selenium.webdriver.chrome.options import Options
            opts = Options()
            opts.add_argument("--headless=new")
            opts.add_argument("--disable-gpu")
            opts.add_argument("--no-sandbox")
            opts.add_argument("--log-level=3")
            opts.add_experimental_option("excludeSwitches", ["enable-logging"])
            try:
                from webdriver_manager.chrome import ChromeDriverManager
                from selenium.webdriver.chrome.service import Service
                driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=opts)
            except Exception:
                driver = webdriver.Chrome(options=opts)
            use_selenium = True
            self.root.after(0, lambda: self.log("  ✔ Chrome 浏览器引擎已启动", "green"))
        except Exception as se:
            err_se = str(se)
            self.root.after(0, lambda: self.log(f"  ⚠ Selenium 不可用，回退到 urllib", "yellow"))

        import urllib.request, ssl, time
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        ok, fail = 0, 0
        loaded_imgs = []

        for i, url in enumerate(urls, 1):
            try:
                self.root.after(0, lambda i=i, n=len(urls): self.log(f"  [{i}/{n}] 下载中…"))
                data = None

                if use_selenium and driver:
                    # 用真实浏览器访问，拿到真实 cookies 和 UA 后再下载
                    driver.get(url)
                    time.sleep(1.5)
                    cookies = driver.get_cookies()
                    ua = driver.execute_script("return navigator.userAgent")
                    req = urllib.request.Request(url)
                    req.add_header("User-Agent", ua)
                    req.add_header("Referer", url)
                    cookie_str = "; ".join([f"{c['name']}={c['value']}" for c in cookies])
                    if cookie_str:
                        req.add_header("Cookie", cookie_str)
                    with urllib.request.urlopen(req, context=ctx, timeout=15) as resp:
                        data = resp.read()
                else:
                    req = urllib.request.Request(url, headers={
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                        "Referer": "https://www.temu.com/",
                    })
                    with urllib.request.urlopen(req, context=ctx, timeout=15) as resp:
                        data = resp.read()

                if data and data[:4] in (b"<htm", b"<!DO", b"<?xm"):
                    raise ValueError("服务器返回了 HTML 而非图片，被防盗链拦截")

                bio = BytesIO(data)
                bio.seek(0)
                img = Image.open(bio)
                img.load()
                img = img.convert("RGB")
                loaded_imgs.append(img)
                ok += 1
                self.root.after(0, lambda i=i: self.log(f"  ✔ 第{i}条成功", "green"))
                self.root.after(0, lambda im=img: self.show_on_canvas(self.canvas1, im))

            except Exception as e:
                fail += 1
                err = str(e)
                self.root.after(0, lambda i=i, err=err: self.log(f"  ✘ 第{i}条失败: {err}", "red"))

        if driver:
            try:
                driver.quit()
            except Exception:
                pass

        def on_done():
            if loaded_imgs:
                self.img1_list = loaded_imgs
                self.img1_pil = loaded_imgs[-1]
                self.show_on_canvas(self.canvas1, loaded_imgs[-1])
                self.log(f"✔ 原图载入完成（共{ok}张），可以粘贴待测图后开始检测", "green")
            else:
                self.log("✘ 全部 URL 均失败。可在浏览器右键图片→复制图片→Ctrl+V 粘贴到程序", "red")
            self.load_btn.config(state=tk.NORMAL, text="批量载入①")

        self.root.after(0, on_done)

    def reset_all(self):
        self.img1_pil = self.img2_pil = None
        for c in (self.canvas1, self.canvas2, self.canvas3):
            c.delete("all")
        self.log_box.delete("1.0", tk.END)
        self.score_bar["value"] = 0
        self.score_label.config(text="—", fg="#cdd6f4")
        self.detect_btn.config(state=tk.NORMAL, text="▶  开始深度检测")
        self.img1_list = []
        self.paste_mode = "original"  # 重置后回到粘贴原图模式
        self.hint_label.config(
            text="📋  使用方法：先 Ctrl+V 粘贴原图（可多次，粘完后点「原图粘贴完毕」），再 Ctrl+V 粘贴待测图",
            fg="#f9e2af")
        self.log("── 已重置，请重新粘贴图片 ──")

    def confirm_originals(self):
        """用户点击「原图粘贴完毕」，切换到粘贴待测图模式"""
        if not self.img1_list and self.img1_pil is None:
            messagebox.showwarning("提示", "还没有粘贴任何原图！")
            return
        self.paste_mode = "test"
        count = len(self.img1_list) if self.img1_list else 1
        self.hint_label.config(
            text=f"✔ 已收集 {count} 张原图  →  现在 Ctrl+V 粘贴待测图",
            fg="#a6e3a1")
        self.log(f"✔ 原图收集完毕（共{count}张），请粘贴待测图", "green")

    def handle_paste(self, event):
        img = ImageGrab.grabclipboard()
        if not isinstance(img, Image.Image):
            messagebox.showwarning("提示", "剪贴板中没有图片")
            return
        img = img.convert("RGB")

        if self.paste_mode == "original":
            # 粘贴原图，支持多张
            self.img1_list.append(img)
            self.img1_pil = img
            self.show_on_canvas(self.canvas1, img)
            count = len(self.img1_list)
            self.log(f"✔ 已粘贴第 {count} 张原图", "green")
            self.hint_label.config(
                text=f"📋  已粘贴 {count} 张原图，继续粘贴或点「原图粘贴完毕」",
                fg="#f9e2af")
        else:
            # 粘贴待测图
            self.img2_pil = img
            self.show_on_canvas(self.canvas2, img)
            self.log("✔ 已粘贴待测图，可以开始检测", "green")
            self.hint_label.config(
                text="✔ 待测图已就绪，点「开始深度检测」",
                fg="#a6e3a1")

    def show_on_canvas(self, canvas, pil_img):
        w, h = pil_img.size
        ratio = min(310 / w, 480 / h)
        resized = pil_img.resize((int(w * ratio), int(h * ratio)),
                                 Image.Resampling.LANCZOS)
        tk_img = ImageTk.PhotoImage(resized)
        canvas.delete("all")
        canvas.create_image(155, 240, image=tk_img)
        canvas.image = tk_img

    # ═══════════════════════ 图像分割（来自v2版） ═══════════════════════

    def segment_objects(self, cv_img, min_size=60):
        """
        用 Canny + 轮廓检测切出图中每个独立物体区域。
        min_size: 过滤掉太小的噪声区域（像素）
        返回: List[{"img": ndarray, "rect": (x,y,w,h)}]
        """
        gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
        # 先做一次高斯模糊减少噪声，再 Canny
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        edges = cv2.Canny(blurred, 40, 120)
        # 膨胀让边缘更连续，合并相邻物体
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
        dilated = cv2.dilate(edges, kernel, iterations=2)

        contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL,
                                       cv2.CHAIN_APPROX_SIMPLE)
        regions = []
        img_h, img_w = cv_img.shape[:2]
        for cnt in contours:
            x, y, w, h = cv2.boundingRect(cnt)
            # 过滤太小 & 几乎覆盖整张图的区域（全局框无意义）
            if w < min_size or h < min_size:
                continue
            if w > img_w * 0.95 and h > img_h * 0.95:
                continue
            regions.append({"img": cv_img[y:y+h, x:x+w], "rect": (x, y, w, h)})

        return regions

    # ═══════════════════════ 算法层 ═══════════════════════════

    # ── 算法A：整图 pHash + 裁剪鲁棒哈希 ─────────────────────
    def score_phash(self, img1: Image.Image, img2: Image.Image) -> float:
        h1 = imagehash.phash(img1, hash_size=16)
        h2 = imagehash.phash(img2, hash_size=16)
        score_normal = max(0.0, 1.0 - (h1 - h2) / 256.0)
        try:
            cr1 = imagehash.crop_resistant_hash(img1)
            cr2 = imagehash.crop_resistant_hash(img2)
            score_crop = cr1.similarity(cr2)
        except Exception:
            score_crop = 0.0
        self.log(f"  pHash:{score_normal:.0%}  裁剪哈希:{score_crop:.0%}")
        return max(score_normal, score_crop)

    # ── 算法B：整图颜色直方图 ─────────────────────────────────
    def score_histogram(self, img1: Image.Image, img2: Image.Image) -> float:
        def to_hist(pil):
            arr = cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2HSV)
            h = cv2.calcHist([arr], [0, 1], None, [50, 60], [0, 180, 0, 256])
            cv2.normalize(h, h)
            return h
        corr = cv2.compareHist(to_hist(img1), to_hist(img2), cv2.HISTCMP_CORREL)
        return float(np.clip((corr + 1) / 2, 0, 1))

    # ── 算法C：整图模板匹配（裁剪专项）─────────────────────────
    def score_template(self, img1_cv, img2_cv) -> float:
        """对原始、左右镜像、上下镜像、180°旋转分别做模板匹配，取最高分"""
        def _match(src_cv, tmpl_cv):
            g1 = cv2.cvtColor(src_cv, cv2.COLOR_BGR2GRAY)
            g2 = cv2.cvtColor(tmpl_cv, cv2.COLOR_BGR2GRAY)
            h1, w1 = g1.shape
            h2, w2 = g2.shape
            if h2 * w2 > h1 * w1:
                g1, g2 = g2, g1
                h1, w1 = g1.shape
                h2, w2 = g2.shape
            scale = min((w1 - 1) / max(w2, 1), (h1 - 1) / max(h2, 1), 1.0)
            if scale < 0.05:
                return 0.0
            tmpl = cv2.resize(g2, (max(1, int(w2 * scale)), max(1, int(h2 * scale))))
            if tmpl.shape[1] >= w1 or tmpl.shape[0] >= h1:
                return 0.0
            try:
                res = cv2.matchTemplate(g1, tmpl, cv2.TM_CCOEFF_NORMED)
                return float(max(0.0, res.max()))
            except Exception:
                return 0.0

        s0 = _match(img1_cv, img2_cv)
        s1 = _match(cv2.flip(img1_cv, 1), img2_cv)   # 左右镜像
        s2 = _match(cv2.flip(img1_cv, 0), img2_cv)   # 上下镜像
        s3 = _match(cv2.flip(img1_cv, -1), img2_cv)  # 180°旋转
        best = max(s0, s1, s2, s3)
        self.log(f"  正向:{s0:.0%} 左右:{s1:.0%} 上下:{s2:.0%} 180°:{s3:.0%}")
        return best

    # ── 算法D：整图 ORB + RANSAC ─────────────────────────────
    def _orb_ransac(self, img1_cv, img2_cv):
        """返回 (score, inliers, homography_matrix)"""
        g1 = cv2.cvtColor(img1_cv, cv2.COLOR_BGR2GRAY)
        g2 = cv2.cvtColor(img2_cv, cv2.COLOR_BGR2GRAY)
        kp1, des1 = self.orb.detectAndCompute(g1, None)
        kp2, des2 = self.orb.detectAndCompute(g2, None)
        if des1 is None or des2 is None or len(kp1) < 5 or len(kp2) < 5:
            return 0.0, 0, None
        bf = cv2.BFMatcher(cv2.NORM_HAMMING)
        raw = bf.knnMatch(des1, des2, k=2)
        good = [m for pair in raw if len(pair) == 2
                for m, n in [pair] if m.distance < 0.75 * n.distance]
        if len(good) < 6:
            return 0.0, 0, None
        src = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
        dst = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
        M, mask = cv2.findHomography(src, dst, cv2.RANSAC, 5.0)
        if mask is None:
            return 0.0, 0, None
        inliers = int(mask.sum())
        return min(1.0, inliers / 30.0), inliers, M

    def score_orb_global(self, img1_cv, img2_cv):
        """整图 ORB，同时测正向/左右镜像/上下镜像，取最高"""
        s1, n1, M1 = self._orb_ransac(img1_cv, img2_cv)
        s2, n2, M2 = self._orb_ransac(cv2.flip(img1_cv, 1), img2_cv)
        s3, n3, M3 = self._orb_ransac(cv2.flip(img1_cv, 0), img2_cv)
        best = max([(s1, n1, M1, "正向"), (s2, n2, M2, "左右镜"), (s3, n3, M3, "上下镜")],
                   key=lambda x: x[0])
        return best  # (score, inliers, M, label)

    # ── 算法E：局部分割 × 交叉 ORB（支持4方向翻转）──────────────
    def score_local_orb(self, img1_cv, img2_cv):
        """
        将两图分别切成物体区域，两两交叉做 ORB 匹配。
        对原图的 正向/左右镜像/上下镜像/180°旋转 四个版本都尝试，取最高。
        返回 (最高局部得分, 命中的 rect_b 列表)
        """
        # 4个方向的原图变体
        img1_variants = [
            (img1_cv,                      "正向"),
            (cv2.flip(img1_cv,  1),        "左右镜像"),
            (cv2.flip(img1_cv,  0),        "上下镜像"),
            (cv2.flip(img1_cv, -1),        "180°旋转"),
        ]

        regions_b = self.segment_objects(img2_cv)
        if not regions_b:
            return 0.0, []

        def adaptive_threshold(w, h):
            area = w * h
            if area > 200 * 200:
                return 25
            elif area > 100 * 100:
                return 15
            else:
                return 8

        local_orb = cv2.ORB_create(3000)

        # 预计算待测图各区域的特征
        desc_b_list = []
        for item_b in regions_b:
            img_b = item_b["img"]
            if img_b.size == 0:
                desc_b_list.append(None)
                continue
            g_b = cv2.cvtColor(img_b, cv2.COLOR_BGR2GRAY)
            kp_b, des_b = local_orb.detectAndCompute(g_b, None)
            desc_b_list.append((kp_b, des_b) if des_b is not None else None)

        best_score = 0.0
        best_hit_rects = []

        for img1_var, vname in img1_variants:
            regions_a = self.segment_objects(img1_var)
            if not regions_a:
                continue

            hit_rects = []
            var_score = 0.0

            for idx_b, item_b in enumerate(regions_b):
                if desc_b_list[idx_b] is None:
                    continue
                kp_b, des_b = desc_b_list[idx_b]

                for item_a in regions_a:
                    img_a = item_a["img"]
                    if img_a.size == 0:
                        continue
                    g_a = cv2.cvtColor(img_a, cv2.COLOR_BGR2GRAY)
                    kp_a, des_a = local_orb.detectAndCompute(g_a, None)
                    if des_a is None:
                        continue

                    bf = cv2.BFMatcher(cv2.NORM_HAMMING)
                    try:
                        raw = bf.knnMatch(des_a, des_b, k=2)
                    except Exception:
                        continue
                    good = [m for pair in raw if len(pair) == 2
                            for m, n in [pair] if m.distance < 0.75 * n.distance]

                    x, y, w, h = item_b["rect"]
                    threshold = adaptive_threshold(w, h)

                    if len(good) >= threshold:
                        if len(good) >= 6:
                            src = np.float32([kp_a[m.queryIdx].pt for m in good]).reshape(-1,1,2)
                            dst = np.float32([kp_b[m.trainIdx].pt for m in good]).reshape(-1,1,2)
                            _, mask = cv2.findHomography(src, dst, cv2.RANSAC, 5.0)
                            verified = int(mask.sum()) if mask is not None else 0
                        else:
                            verified = len(good)

                        if verified >= max(4, threshold // 2):
                            norm = min(1.0, verified / 30.0)
                            var_score = max(var_score, norm)
                            if item_b["rect"] not in hit_rects:
                                hit_rects.append(item_b["rect"])
                            self.log(f"  ✦ [{vname}] 局部命中！内点:{verified} 区域:{w}×{h}", "cyan")
                            break

            if var_score > best_score:
                best_score = var_score
                best_hit_rects = hit_rects

        regions_a_count = len(self.segment_objects(img1_cv))
        self.log(f"  原图切出 {regions_a_count} 区域 / 待测图切出 {len(regions_b)} 区域")
        return best_score, best_hit_rects

    # ═══════════════════════ 主流程 ═══════════════════════════

    def start_detection(self):
        """在子线程中运行，避免 UI 卡死"""
        if self.img1_pil is None and self.img2_pil is None:
            messagebox.showerror("错误", "请先输入原图 URL 并载入，再用 Ctrl+V 粘贴待测图")
            return
        if self.img1_pil is None:
            messagebox.showerror("错误", "原图未载入，请在 URL 框输入原图地址并点击「批量载入①」")
            return
        if self.img2_pil is None:
            messagebox.showerror("错误", "待测图未载入，请用 Ctrl+V 粘贴截图")
            return
        self.detect_btn.config(state=tk.DISABLED, text="检测中…")
        t = threading.Thread(target=self.process_comparison, daemon=True)
        t.start()

    def process_comparison(self):
        try:
            self._do_compare()
        except Exception as e:
            self.log(f"[错误] {e}", "red")
        finally:
            self.detect_btn.config(state=tk.NORMAL, text="▶  开始深度检测")

    def _do_compare(self):
        self.log_box.delete("1.0", tk.END)
        src_list = self.img1_list if self.img1_list else [self.img1_pil]
        total = len(src_list)
        self.log(f"══ 开始检测（原图共{total}张）══")

        all_results = []
        for idx, img1 in enumerate(src_list, 1):
            self.log(f"\n── 第{idx}/{total}张原图 ──", "yellow")
            self.show_on_canvas(self.canvas1, img1)
            self.root.update_idletasks()
            result = self._compare_one(img1, self.img2_pil)
            result["idx"] = idx
            result["img1"] = img1
            all_results.append(result)

        # 汇总所有结果
        self.log("\n" + "═"*28, "normal")
        self.log("【汇总】每张原图检测结果：", "cyan")
        hit_list = []
        for r in all_results:
            pct = r["final_pct"]
            if pct >= 65:
                tag, mark = "red", "⚠盗图"
            elif pct >= 40:
                tag, mark = "yellow", "⚡待复查"
            else:
                tag, mark = "green", "✔正常"
            self.log(f"  原图第{r['idx']}张: {pct}%  {mark}", tag)
            if pct >= 40:
                hit_list.append(r)

        if hit_list:
            self.log(f"\n共命中 {len(hit_list)}/{total} 张原图！", "red")
        else:
            self.log("\n未发现盗图", "green")

        # 画布展示得分最高的那张原图的结果
        best = max(all_results, key=lambda r: r["final_pct"])
        self.show_on_canvas(self.canvas1, best["img1"])
        self._show_result(best)

    def _compare_one(self, img1, img2):
        img1_cv = cv2.cvtColor(np.array(img1), cv2.COLOR_RGB2BGR)
        img2_cv = cv2.cvtColor(np.array(img2), cv2.COLOR_RGB2BGR)

        # ── A: pHash ──────────────────────────────────────────
        self.log("▸ [A] 感知哈希", "yellow")
        ph_score = self.score_phash(img1, img2)
        self.log(f"  → {ph_score:.1%}")

        # ── B: 直方图 ─────────────────────────────────────────
        self.log("▸ [B] 颜色直方图", "yellow")
        hist_score = self.score_histogram(img1, img2)
        self.log(f"  → {hist_score:.1%}")

        # ── C: 模板匹配 ───────────────────────────────────────
        self.log("▸ [C] 模板匹配（裁剪专项）", "yellow")
        tmpl_score = self.score_template(img1_cv, img2_cv)
        self.log(f"  → {tmpl_score:.1%}")

        # ── D: 整图 ORB+RANSAC ───────────────────────────────
        self.log("▸ [D] 整图 ORB+RANSAC", "yellow")
        orb_score, inliers, M, orb_label = self.score_orb_global(img1_cv, img2_cv)
        self.log(f"  → {orb_score:.1%}  内点:{inliers}  ({orb_label})")

        # ── E: 局部分割 × 交叉 ORB ──────────────────────────
        self.log("▸ [E] 局部分割×ORB（核心）", "yellow")
        local_score, hit_rects = self.score_local_orb(img1_cv, img2_cv)
        self.log(f"  → {local_score:.1%}  命中区域:{len(hit_rects)}")

        # ── 加权融合 ─────────────────────────────────────────
        # E（局部分割）权重最高，是本版核心优势
        # C（模板匹配）专攻裁剪，权重次高
        # D（整图ORB）、A（pHash）补充全局相似性
        # B（直方图）仅辅助
        final = (0.35 * local_score
                 + 0.25 * tmpl_score
                 + 0.20 * orb_score
                 + 0.15 * ph_score
                 + 0.05 * hist_score)

        # 如果局部命中 或 模板/ORB 任意一个极高，直接拉升分数
        if local_score > 0.5 or tmpl_score > 0.85 or orb_score > 0.8:
            final = max(final, 0.70)

        final_pct = int(final * 100)
        self.log(f"\n综合相似度: {final_pct}%")

        # 构建结果图
        result_img = img2_cv.copy()
        for rect in hit_rects:
            x, y, w, h = rect
            cv2.rectangle(result_img, (x, y), (x+w, y+h), (0, 0, 255), 3)
            cv2.putText(result_img, "MATCH", (x, max(y-8, 12)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
        if M is not None and final_pct >= 40 and not hit_rects:
            h0, w0 = img1_cv.shape[:2]
            pts = np.float32([[0,0],[0,h0-1],[w0-1,h0-1],[w0-1,0]]).reshape(-1,1,2)
            try:
                dst = cv2.perspectiveTransform(pts, M)
                cv2.polylines(result_img, [np.int32(dst)], True, (255, 80, 0), 3, cv2.LINE_AA)
            except Exception:
                pass

        return {
            "final_pct": final_pct,
            "hit_rects": hit_rects,
            "M": M,
            "img1_cv": img1_cv,
            "img2_cv": img2_cv,
            "result_img": result_img,
        }

    def _show_result(self, r):
        final_pct = r["final_pct"]
        self.score_bar["value"] = final_pct
        if final_pct >= 65:
            verdict, color, bar_color = "⚠ 高度疑似盗图", "red", "#f38ba8"
        elif final_pct >= 40:
            verdict, color, bar_color = "⚡ 存在相似性，建议人工复查", "yellow", "#f9e2af"
        else:
            verdict, color, bar_color = "✔ 未发现明显盗图特征", "green", "#a6e3a1"
        self.score_label.config(text=f"{final_pct}%  {verdict}", fg=bar_color)
        self.log(f"\n最终判定: {verdict}", color)
        res_pil = Image.fromarray(cv2.cvtColor(r["result_img"], cv2.COLOR_BGR2RGB))
        self.show_on_canvas(self.canvas3, res_pil)
        self.log("\n══ 检测完成 ══")


# ═══════════════════════════ 入口 ═══════════════════════════

if __name__ == "__main__":
    root = tk.Tk()
    app = AntiTheftApp(root)
    root.mainloop()
