import tkinter as tk
from tkinter import messagebox, simpledialog
from tkinter import ttk
import json
import os

try:
    import pyperclip
    HAS_PYPERCLIP = True
except ImportError:
    HAS_PYPERCLIP = False

import platform
import subprocess

DATA_FILE = os.path.join(os.path.expanduser("~"), "clipboard_data.json")

default_data = {
    "投诉": {
        "items": [
            "To whom it may concern,",
            "We are writing to bring to your attention that..."
        ],
        "children": {}
    },
    "商务": {
        "items": [
            "Thank you for your cooperation.",
            "Please let us know if you need further assistance."
        ],
        "children": {}
    }
}

current_category = None
current_subcategory = None
_shift_anchor = None   # 用于 Shift 范围选择的锚点

def load_data():
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                for key in list(data.keys()):
                    if isinstance(data[key], list):
                        data[key] = {"items": data[key], "children": {}}
                return data
        except:
            return default_data
    return default_data

def save_data():
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def copy_text(text):
    try:
        if HAS_PYPERCLIP:
            pyperclip.copy(text)
            return True
    except:
        pass
    try:
        system = platform.system()
        if system == "Windows":
            process = subprocess.Popen(['clip'], stdin=subprocess.PIPE, stderr=subprocess.PIPE)
            process.communicate(text.encode('utf-8'))
            return process.returncode == 0
        elif system == "Darwin":
            process = subprocess.Popen(['pbcopy'], stdin=subprocess.PIPE, stderr=subprocess.PIPE)
            process.communicate(text.encode('utf-8'))
            return process.returncode == 0
        else:
            try:
                process = subprocess.Popen(['xclip', '-selection', 'clipboard'], stdin=subprocess.PIPE, stderr=subprocess.PIPE)
                process.communicate(text.encode('utf-8'))
                return process.returncode == 0
            except:
                pass
    except:
        pass
    try:
        root.clipboard_clear()
        root.clipboard_append(text)
        root.update()
        return True
    except:
        return False

def refresh_tree():
    for item in category_tree.get_children():
        category_tree.delete(item)
    for category in data:
        category_id = category_tree.insert("", tk.END, text=category, open=True, tags=("category",))
        children = data[category].get("children", {})
        for subfolder in children:
            category_tree.insert(category_id, tk.END, text=subfolder, tags=("subfolder",))

def refresh_items(category, subcategory=None):
    item_listbox.delete(0, tk.END)
    if subcategory:
        items = data[category]["children"][subcategory].get("items", [])
    else:
        items = data[category].get("items", [])
    for item in items:
        item_listbox.insert(tk.END, item)

def on_tree_select(event):
    global current_category, current_subcategory
    selection = category_tree.selection()
    if not selection:
        return
    item_id = selection[0]
    tags = category_tree.item(item_id, "tags")
    text = category_tree.item(item_id, "text")
    if "category" in tags:
        current_category = text
        current_subcategory = None
        refresh_items(current_category)
    elif "subfolder" in tags:
        parent_id = category_tree.parent(item_id)
        if parent_id:
            current_category = category_tree.item(parent_id, "text")
            current_subcategory = text
            refresh_items(current_category, current_subcategory)

def on_item_double_click(event):
    """双击：复制常用语。"""
    global current_category, current_subcategory
    index = item_listbox.nearest(event.y)
    if index < 0 or not current_category:
        return "break"
    if current_subcategory:
        text = data[current_category]["children"][current_subcategory]["items"][index]
    else:
        text = data[current_category]["items"][index]
    if text:
        copy_text(text)
    return "break"

def on_item_triple_click(event):
    """三击：编辑常用语。"""
    index = item_listbox.nearest(event.y)
    if index < 0 or not current_category:
        return "break"
    edit_item(index)
    return "break"

def on_item_click(event):
    """处理左键单击，实现 Ctrl 多选和 Shift 范围选。"""
    global _shift_anchor
    if not current_category:
        return
    index = item_listbox.nearest(event.y)
    if index < 0:
        return

    ctrl  = (event.state & 0x0004) != 0
    shift = (event.state & 0x0001) != 0

    if shift and _shift_anchor is not None:
        # Shift：从锚点到当前行全选（保留已有 Ctrl 选择）
        lo, hi = min(_shift_anchor, index), max(_shift_anchor, index)
        if not ctrl:
            item_listbox.selection_clear(0, tk.END)
        for i in range(lo, hi + 1):
            item_listbox.selection_set(i)
    elif ctrl:
        # Ctrl：切换当前行选中状态，锚点移到当前行
        if item_listbox.selection_includes(index):
            item_listbox.selection_clear(index)
        else:
            item_listbox.selection_set(index)
        _shift_anchor = index
    else:
        # 普通单击：清除其他选择
        item_listbox.selection_clear(0, tk.END)
        item_listbox.selection_set(index)
        _shift_anchor = index

    return "break"   # 阻止 Listbox 默认选择行为

def delete_selected_items():
    """删除当前所有选中的常用语（支持多选）。"""
    global current_category, current_subcategory
    if not current_category:
        return
    selected = list(item_listbox.curselection())
    if not selected:
        return
    n = len(selected)
    tip = f"确定删除选中的 {n} 条常用语吗？" if n > 1 else "确定删除这条常用语吗？"
    if not messagebox.askyesno("确认删除", tip):
        return
    # 从大到小删，避免索引错位
    items = _get_current_items()
    for idx in sorted(selected, reverse=True):
        if idx < len(items):
            del items[idx]
    save_data()
    refresh_items(current_category, current_subcategory)

def on_item_right_click(event):
    global current_category, current_subcategory
    index = item_listbox.nearest(event.y)
    if index < 0 or not current_category:
        return

    # 如果右键点到的行不在已选集合里，重置为单选该行
    if not item_listbox.selection_includes(index):
        item_listbox.selection_clear(0, tk.END)
        item_listbox.selection_set(index)
        global _shift_anchor
        _shift_anchor = index

    selected = list(item_listbox.curselection())
    menu = tk.Menu(root, tearoff=0)
    if len(selected) == 1:
        menu.add_command(label="编辑", command=lambda: edit_item(selected[0]))
    menu.add_command(
        label=f"删除（共 {len(selected)} 条）" if len(selected) > 1 else "删除",
        command=delete_selected_items
    )
    menu.post(event.x_root, event.y_root)

def on_tree_right_click(event):
    item_id = category_tree.identify("item", event.x, event.y)
    if not item_id:
        return
    category_tree.selection_set(item_id)
    tags = category_tree.item(item_id, "tags")
    text = category_tree.item(item_id, "text")
    menu = tk.Menu(root, tearoff=0)
    if "category" in tags:
        menu.add_command(label="编辑", command=lambda: edit_category(item_id, text))
        menu.add_command(label="删除", command=lambda: delete_category(text))
    elif "subfolder" in tags:
        parent_id = category_tree.parent(item_id)
        category = category_tree.item(parent_id, "text")
        menu.add_command(label="编辑", command=lambda: edit_subfolder(item_id, category, text))
        menu.add_command(label="删除", command=lambda: delete_subfolder(category, text))
    menu.post(event.x_root, event.y_root)

def edit_category(item_id, old_name):
    new_name = simpledialog.askstring("编辑栏目", "请输入新的栏目名称：", initialvalue=old_name)
    if new_name and new_name != old_name:
        if new_name in data:
            messagebox.showwarning("提示", "栏目名称已存在")
            return
        data[new_name] = data.pop(old_name)
        save_data()
        refresh_tree()

def edit_subfolder(item_id, category, old_name):
    new_name = simpledialog.askstring("编辑子文件夹", "请输入新的子文件夹名称：", initialvalue=old_name)
    if new_name and new_name != old_name:
        if new_name in data[category]["children"]:
            messagebox.showwarning("提示", "子文件夹名称已存在")
            return
        data[category]["children"][new_name] = data[category]["children"].pop(old_name)
        save_data()
        refresh_tree()

def edit_item(index):
    global current_category, current_subcategory
    if not current_category:
        return
    if current_subcategory:
        old_text = data[current_category]["children"][current_subcategory]["items"][index]
    else:
        old_text = data[current_category]["items"][index]
    
    # ── 弹出可伸缩编辑对话框 ──────────────────────────────────────
    dialog = tk.Toplevel(root)
    dialog.title("编辑常用语")
    dialog.grab_set()
    dialog.resizable(True, True)

    tk.Label(dialog, text="请输入内容：").pack(anchor="w", padx=10, pady=(10, 2))

    text_frame = tk.Frame(dialog)
    text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=2)

    text_widget = tk.Text(text_frame, width=50, height=5, wrap=tk.WORD)
    text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    sb = tk.Scrollbar(text_frame, command=text_widget.yview)
    sb.pack(side=tk.RIGHT, fill=tk.Y)
    text_widget.config(yscrollcommand=sb.set)
    text_widget.insert("1.0", old_text)

    result = [None]

    def on_ok():
        result[0] = text_widget.get("1.0", tk.END).rstrip("\n")
        dialog.destroy()

    def on_cancel():
        dialog.destroy()

    btn_row = tk.Frame(dialog)
    btn_row.pack(fill=tk.X, padx=10, pady=(2, 10))
    tk.Button(btn_row, text="OK", command=on_ok, width=8).pack(side=tk.LEFT, padx=4)
    tk.Button(btn_row, text="Cancel", command=on_cancel, width=8).pack(side=tk.LEFT)

    dialog.wait_window()

    new_text = result[0]
    if new_text is not None and new_text != old_text:
        if current_subcategory:
            data[current_category]["children"][current_subcategory]["items"][index] = new_text
        else:
            data[current_category]["items"][index] = new_text
        save_data()
        refresh_items(current_category, current_subcategory)

def delete_category(category):
    if messagebox.askyesno("确认删除", f"确定删除栏目「{category}」吗？"):
        del data[category]
        save_data()
        refresh_tree()
        item_listbox.delete(0, tk.END)

def delete_subfolder(category, subfolder):
    if messagebox.askyesno("确认删除", f"确定删除子文件夹「{subfolder}」吗？"):
        del data[category]["children"][subfolder]
        save_data()
        refresh_tree()

def delete_item(index):
    """单条删除（供编辑菜单等处调用）。"""
    global current_category, current_subcategory
    if not current_category:
        return
    if messagebox.askyesno("确认删除", "确定删除这条常用语吗？"):
        items = _get_current_items()
        if index < len(items):
            del items[index]
        save_data()
        refresh_items(current_category, current_subcategory)

def add_category():
    name = simpledialog.askstring("新增栏目", "请输入栏目名称：")
    if name:
        if name in data:
            messagebox.showwarning("提示", "栏目已存在")
            return
        data[name] = {"items": [], "children": {}}
        save_data()
        refresh_tree()

def add_subfolder():
    selection = category_tree.selection()
    if not selection:
        messagebox.showwarning("提示", "请先选择主栏目")
        return
    item_id = selection[0]
    if "category" not in category_tree.item(item_id, "tags"):
        messagebox.showwarning("提示", "请选择栏目来新增子文件夹")
        return
    category = category_tree.item(item_id, "text")
    name = simpledialog.askstring("新增子文件夹", "请输入子文件夹名称：")
    if name:
        if name in data[category]["children"]:
            messagebox.showwarning("提示", "子文件夹已存在")
            return
        data[category]["children"][name] = {"items": [], "children": {}}
        save_data()
        refresh_tree()

def add_item():
    global current_category, current_subcategory
    if not current_category:
        messagebox.showwarning("提示", "请先选择左侧栏目或子文件夹")
        return

    # ── 弹出可伸缩新增对话框 ──────────────────────────────────────
    dialog = tk.Toplevel(root)
    dialog.title("新增常用语")
    dialog.grab_set()
    dialog.resizable(True, True)

    tk.Label(dialog, text="请输入常用语：").pack(anchor="w", padx=10, pady=(10, 2))

    text_frame = tk.Frame(dialog)
    text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=2)

    text_widget = tk.Text(text_frame, width=50, height=5, wrap=tk.WORD)
    text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    sb = tk.Scrollbar(text_frame, command=text_widget.yview)
    sb.pack(side=tk.RIGHT, fill=tk.Y)
    text_widget.config(yscrollcommand=sb.set)

    result = [None]

    def on_ok():
        result[0] = text_widget.get("1.0", tk.END).rstrip("\n")
        dialog.destroy()

    def on_cancel():
        dialog.destroy()

    btn_row = tk.Frame(dialog)
    btn_row.pack(fill=tk.X, padx=10, pady=(2, 10))
    tk.Button(btn_row, text="OK", command=on_ok, width=8).pack(side=tk.LEFT, padx=4)
    tk.Button(btn_row, text="Cancel", command=on_cancel, width=8).pack(side=tk.LEFT)

    dialog.wait_window()

    text = result[0]
    if text:
        if current_subcategory:
            data[current_category]["children"][current_subcategory]["items"].append(text)
        else:
            data[current_category]["items"].append(text)
        save_data()
        refresh_items(current_category, current_subcategory)

def toggle_topmost():
    current = root.attributes("-topmost")
    root.attributes("-topmost", not current)

# ══════════════════════════════════════════════════════════════════════
#  拖拽排序 —— 左侧 Treeview（栏目 / 子文件夹）
# ══════════════════════════════════════════════════════════════════════
_tree_drag_item = None

def _tree_drag_start(event):
    global _tree_drag_item
    item_id = category_tree.identify_row(event.y)
    if item_id:
        _tree_drag_item = item_id
        category_tree.selection_set(item_id)

def _tree_drag_motion(event):
    if not _tree_drag_item:
        return
    target_id = category_tree.identify_row(event.y)
    if target_id and target_id != _tree_drag_item:
        category_tree.selection_set(target_id)   # 高亮目标

def _tree_drag_release(event):
    global _tree_drag_item
    if not _tree_drag_item:
        return

    target_id = category_tree.identify_row(event.y)
    src_id = _tree_drag_item
    _tree_drag_item = None

    if not target_id or target_id == src_id:
        return

    src_tags  = category_tree.item(src_id,  "tags")
    tgt_tags  = category_tree.item(target_id, "tags")
    src_text  = category_tree.item(src_id,  "text")
    tgt_text  = category_tree.item(target_id, "text")

    # ── 同层 category 排序 ──
    if "category" in src_tags and "category" in tgt_tags:
        keys = list(data.keys())
        si, ti = keys.index(src_text), keys.index(tgt_text)
        keys.insert(ti, keys.pop(si))
        reordered = {k: data[k] for k in keys}
        data.clear(); data.update(reordered)
        save_data(); refresh_tree()
        return

    # ── 同父 subfolder 排序 ──
    if "subfolder" in src_tags and "subfolder" in tgt_tags:
        src_parent = category_tree.parent(src_id)
        tgt_parent = category_tree.parent(target_id)
        if src_parent == tgt_parent:
            cat = category_tree.item(src_parent, "text")
            ch  = data[cat]["children"]
            keys = list(ch.keys())
            si, ti = keys.index(src_text), keys.index(tgt_text)
            keys.insert(ti, keys.pop(si))
            reordered = {k: ch[k] for k in keys}
            ch.clear(); ch.update(reordered)
            save_data(); refresh_tree()

# ══════════════════════════════════════════════════════════════════════
#  拖拽排序 —— 右侧 Listbox（常用语）
#  同时支持将常用语 拖到左侧 Treeview 节点，跨栏目移动
# ══════════════════════════════════════════════════════════════════════
_lb_drag_index = None
_drag_label    = None   # 跟随鼠标的浮动标签

def _get_current_items():
    if current_subcategory:
        return data[current_category]["children"][current_subcategory]["items"]
    return data[current_category]["items"]

def _lb_drag_start(event):
    global _lb_drag_index, _drag_label
    if not current_category:
        return
    # Ctrl/Shift 时不启动拖拽
    ctrl  = (event.state & 0x0004) != 0
    shift = (event.state & 0x0001) != 0
    if ctrl or shift:
        return

    idx = item_listbox.nearest(event.y)
    if idx < 0:
        return
    # 只有点到已选中项才准备拖拽（避免单击新行时误触发）
    _lb_drag_index = idx

    # 创建跟随鼠标的浮动提示标签
    items = _get_current_items()
    if idx < len(items):
        preview = items[idx][:30] + ("…" if len(items[idx]) > 30 else "")
        _drag_label = tk.Label(root, text=preview, bg="#ffffaa", relief="solid",
                               font=("Arial", 9), padx=4, pady=2)
        _drag_label.place(x=event.x_root - root.winfo_rootx() + 8,
                          y=event.y_root - root.winfo_rooty() + 8)

def _lb_drag_motion(event):
    if _drag_label:
        _drag_label.place(x=event.x_root - root.winfo_rootx() + 8,
                          y=event.y_root - root.winfo_rooty() + 8)

def _destroy_drag_label():
    global _drag_label
    if _drag_label:
        _drag_label.destroy()
        _drag_label = None

def _lb_drag_release(event):
    global _lb_drag_index
    _destroy_drag_label()

    if _lb_drag_index is None or not current_category:
        return

    src_index = _lb_drag_index
    _lb_drag_index = None

    # ── 检查鼠标是否落在左侧 Treeview 上 ──────────────────────────
    wx = event.x_root - category_tree.winfo_rootx()
    wy = event.y_root - category_tree.winfo_rooty()
    tree_w = category_tree.winfo_width()
    tree_h = category_tree.winfo_height()

    if 0 <= wx <= tree_w and 0 <= wy <= tree_h:
        # 拖到了左侧 —— 跨栏目移动
        target_id = category_tree.identify_row(wy)
        if not target_id:
            return

        tgt_tags = category_tree.item(target_id, "tags")
        if "category" in tgt_tags:
            tgt_cat = category_tree.item(target_id, "text")
            tgt_sub = None
        elif "subfolder" in tgt_tags:
            parent_id = category_tree.parent(target_id)
            tgt_cat = category_tree.item(parent_id, "text")
            tgt_sub = category_tree.item(target_id, "text")
        else:
            return

        # 不能移到来源本身
        if tgt_cat == current_category and tgt_sub == current_subcategory:
            return

        items = _get_current_items()
        if src_index >= len(items):
            return

        moved_text = items.pop(src_index)

        if tgt_sub:
            data[tgt_cat]["children"][tgt_sub]["items"].append(moved_text)
        else:
            data[tgt_cat]["items"].append(moved_text)

        save_data()
        refresh_items(current_category, current_subcategory)
        return

    # ── 否则在 Listbox 内排序 ─────────────────────────────────────
    tgt_index = item_listbox.nearest(event.y)
    if tgt_index < 0 or tgt_index == src_index:
        return

    items = _get_current_items()
    if src_index >= len(items) or tgt_index >= len(items):
        return

    item = items.pop(src_index)
    items.insert(tgt_index, item)
    save_data()
    refresh_items(current_category, current_subcategory)
    item_listbox.selection_set(tgt_index)

# ══════════════════════════════════════════════════════════════════════
#  构建 UI
# ══════════════════════════════════════════════════════════════════════
data = load_data()

root = tk.Tk()
root.title("多栏目剪贴板")

# ── 顶部置顶按钮 ──────────────────────────────────────────────────────
top_frame = tk.Frame(root)
top_frame.pack(fill=tk.X, padx=5, pady=2)
tk.Button(top_frame, text="置顶", command=toggle_topmost, width=5, bg="#e0e0e0").pack(side=tk.RIGHT, padx=2)

# ── 底部按钮区（先 pack，保证缩小时不被遮挡）────────────────────────
bottom_frame = tk.Frame(root)
bottom_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=5, pady=4)

def add_subfolder_bottom():
    """从底部按钮调用，逻辑同 add_subfolder"""
    add_subfolder()

tk.Button(bottom_frame, text="新增栏目",    command=add_category,        width=10).pack(side=tk.LEFT, padx=2)
tk.Button(bottom_frame, text="新增子文件夹", command=add_subfolder_bottom, width=10).pack(side=tk.LEFT, padx=2)
tk.Button(bottom_frame, text="新增常用语",  command=add_item,            width=10).pack(side=tk.LEFT, padx=2)

# ── 主内容区（PanedWindow）────────────────────────────────────────────
main_frame = tk.Frame(root)
main_frame.pack(fill=tk.BOTH, expand=True)

func_paned = tk.PanedWindow(main_frame, orient=tk.HORIZONTAL, sashwidth=5)
func_paned.pack(fill=tk.BOTH, expand=True)

# ── 左侧 ──────────────────────────────────────────────────────────────
left_frame = tk.Frame(func_paned)
func_paned.add(left_frame, width=170)

tk.Label(left_frame, text="栏目", font=("Arial", 10, "bold")).pack(anchor="w", padx=5, pady=(5, 2))

tree_frame = tk.Frame(left_frame)
tree_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=2)

category_tree = ttk.Treeview(tree_frame, show="tree")
tree_scroll = tk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=category_tree.yview)
category_tree.configure(yscrollcommand=tree_scroll.set)
tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)
category_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

category_tree.tag_configure("category",  font=("Arial", 10, "bold"))
category_tree.tag_configure("subfolder", font=("Arial", 9))

category_tree.bind("<<TreeviewSelect>>", on_tree_select)
category_tree.bind("<Button-3>",         on_tree_right_click)
# 拖拽排序（只在树区域，排除滚动条区域）
category_tree.bind("<ButtonPress-1>",    _tree_drag_start)
category_tree.bind("<B1-Motion>",        _tree_drag_motion)
category_tree.bind("<ButtonRelease-1>",  _tree_drag_release)

# ── 右侧 ──────────────────────────────────────────────────────────────
right_frame = tk.Frame(func_paned)
func_paned.add(right_frame)

tk.Label(right_frame, text="常用语 (直接双击复制)", font=("Arial", 10, "bold"), fg="darkgreen").pack(anchor="w", padx=5, pady=(5, 2))

lb_frame = tk.Frame(right_frame)
lb_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=2)

item_listbox = tk.Listbox(lb_frame, selectmode=tk.EXTENDED)
lb_scroll = tk.Scrollbar(lb_frame, orient=tk.VERTICAL, command=item_listbox.yview)
item_listbox.configure(yscrollcommand=lb_scroll.set)
lb_scroll.pack(side=tk.RIGHT, fill=tk.Y)
item_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

item_listbox.bind("<Double-Button-1>", on_item_double_click)
item_listbox.bind("<Triple-Button-1>", on_item_triple_click)
item_listbox.bind("<Button-3>",        on_item_right_click)

def _on_lb_press(event):
    on_item_click(event)    # Ctrl/Shift 多选逻辑
    _lb_drag_start(event)   # 拖拽准备（Ctrl/Shift 时内部会跳过）

item_listbox.bind("<ButtonPress-1>",   _on_lb_press)
item_listbox.bind("<Delete>",          lambda e: delete_selected_items())  # Delete 键批量删除
# 拖拽排序 / 跨栏目移动绑定
item_listbox.bind("<B1-Motion>",       _lb_drag_motion)
item_listbox.bind("<ButtonRelease-1>", _lb_drag_release)

# ── 自动计算初始窗口大小（适配内容）────────────────────────────────
def _auto_size():
    root.update_idletasks()
    # 统计树中行数，计算合适高度
    row_h    = 20          # 每行约 20px
    n_rows   = sum(1 + len(data[c].get("children", {})) for c in data)
    tree_h   = max(n_rows * row_h, 100)
    # 窗口高度 = 顶部 + 底部按钮 + 标签 + 列表 + 边距
    win_h    = tree_h + 90
    win_h    = max(win_h, 200)
    win_h    = min(win_h, root.winfo_screenheight() - 100)
    win_w    = 700
    root.geometry(f"{win_w}x{win_h}")
    root.minsize(400, 180)   # 缩到极小时也保证按钮可见

refresh_tree()
root.after(50, _auto_size)   # 等布局稳定后再测量
root.mainloop()
